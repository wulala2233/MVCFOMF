 
clc;
clear;

load Handwritten;
% NMI=0.9357(0.0000),  ACC=0.9710(0.0000),  F-score=0.9431(0.0000),Purity=0.9710(0.0000) alf=0.050 	beita=0.050 	gamma=0.200 	s=0.200 	 accMax=0.9710
% NMI=0.9449(0.0000),  ACC=0.9760(0.0000),  F-score=0.9528(0.0000),Purity=0.9760(0.0000) alf=0.050 	beita=0.050 	gamma=0.500 	s=0.200 	 accMax=0.9760
% NMI=0.9536(0.0000),  ACC=0.9805(0.0000),  F-score=0.9616(0.0000),Purity=0.9805(0.0000) alf=0.050 	beita=0.500 	gamma=5.000 	s=0.200 	 accMax=0.9805

fprintf('HW\n')
 

%%%%%%%%%%%%%%%%%%%%%%%%
% load nus
% for i=1:6
%    data{i}=X{i}; 
% end

%%%%%%%%%%%%%%%%%%%%%%%%

 

 nCluster=length(unique(Y));
 nnn=200;
 nc=200;
for iv=1:6
    X{iv}=X{iv}';
    x=X{iv};
    aa=[];
   for i=1:nCluster
    a=(i-1)*nc;
    b=x(:,a+1:(a+nnn));
    aa=[aa b];
   end
   X{iv}=aa;
end
YY=[];
for i=1:nCluster
    a=(i-1)*nc;
    b=Y(a+1:a+nnn,:); 
    YY=[YY;b];
end

 for iv = 1:6
   X{iv} =NormalizeFea(X{iv},1); 
 end
 
    alf_1= [  0.05];
    beita_1=[0.5 ];
   gamma_1=[ 5   ];%ѡ���ڵ������λ
    ss_1=[0.1];
    temp=0;
    for i=1:length(alf_1)
        alf=alf_1(i);
        for j=1:length(beita_1)
            beita=beita_1(j);
            for ij=1:length(gamma_1)
               gamma=gamma_1(ij);
               for it=1:length(ss_1)
                   s=ss_1(it);
             for rep=1:1
                 tic;
                   [P1,Zx]=Zv_and_Zx(X,YY,alf,beita,gamma,nCluster,s);
                   toc;
%                    [U,V]  = CBFMSC(X,opts);
                   [nmi(rep),acc(rep),f(rep),purity(rep),idx]=zhixing_Kmeans(P1,nCluster,YY);
                   %fprintf('nmi=%.4f,  acc=%.4f,  f=%.4f, purity=%.4f \n',nmi(rep),acc(rep),f(rep),purity(rep));
               end
              ACC=mean(acc);
              NMI=mean(nmi);
              F=mean(f);
              Purity=mean(purity);
               if(temp<= ACC)
                   temp= ACC;
               end
                 fprintf('NMI=%.4f(%.4f),  ACC=%.4f(%.4f),  F-score=%.4f(%.4f),Purity=%.4f(%.4f) alf=%.3f \tbeita=%.3f \tgamma=%.3f \ts=%.3f \t accMax=%.4f\n',NMI,std(nmi),ACC,std(acc),F,std(f),Purity,std(purity),alf,beita,gamma,s,temp);
                   end
            end
        end
    end
 figure(2);
  mappedX  = tsne(P1,'Algorithm','barneshut','Distance','correlation');
   gscatter(mappedX(:,1), mappedX(:,2), Y );
% x=[];
% for i=1:length(value)
%     x=[x,i];
% end
%  plot(x,value,'r-','LineWidth',2);
%  xlabel('Iteration');
%  ylabel('Objective function value') ;
%  ylabel('Objective function value') ; 